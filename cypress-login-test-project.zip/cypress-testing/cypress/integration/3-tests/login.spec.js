var logoutMainPage = ".MailBox_wrapper__Hl26A .button_button__uyUBi";
var logoutMailPage = ".header-navigation-wrap #qa_logout_ju2";
var emailSubject = "Test email message with attachment";
var emailBody = "Here I type some text about this message with attachment";

describe("Login tests", () => {
  beforeEach(() => {
    cy.visit(Cypress.env("mainUrl"));
  });

  function fillLoginFields(Username, Password) {
    cy.get(".MailBox_wrapper__Hl26A #username").click().clear().type(Username);
    cy.get(".MailBox_wrapper__Hl26A #password").click().clear().type(Password);
  }

  function checkUrl(url) {
    cy.url().should("eq", url);
  }

  function login() {
    // click on login button
    cy.get(
      ".wrappers_right__tddKM > .MailBox_wrapper__Hl26A .button_button-orange__XPSX7"
    )
      .should("contain", "Prihlásiť")
      .click();
  }

  function verifyIfUserIsLoggedIn() {
    // check if correct mail address is displayed on button
    cy.get(".MailBox_mail__fRH5Q")
      .should("contain", Cypress.env("username"))
      // now click on this button that allows entering the mailbox:
      .click();

    // check if user is redirected to home page
    checkUrl(Cypress.env("mailUrl"));

    // check if correct mail adress is displayed in navigation bar:
    cy.get(".header-navigation-inner strong").should(
      "contain",
      Cypress.env("username")
    );
  }

  function logout(selector) {
    cy.get(selector).should("contain", "Odhlásiť").click();
  }

  function checkErrorMessage(errorMessage) {
    cy.get(".MailBox_wrapper__Hl26A .forms_box-error__BBvHI").should(
      "contain",
      errorMessage
    );

    // check its backgorund color
    cy.get(".MailBox_wrapper__Hl26A .forms_box-error__BBvHI").should(
      "have.css",
      "background-color",
      "rgb(196, 45, 45)"
    );
  }

  function writeNewMail() {
    cy.get(".col-left-email #compose_button")
      .should("contain", "Napísať správu")
      .click();
  }

  function selectFromContacts(contact) {
    // click on saved contacts icon:
    cy.get("#qabook_switch_names").click();

    // check if in contacts there is already mail address where mail should be sent
    cy.get("#quickabook_div #qcontact_0 > span")
      .dblclick()
      .click({ force: true });

    // check if selected contact is inserted in recipients field
    cy.get(".recipient-address").should("contain", contact);
  }

  function addSubject(subject) {
    cy.get("#subject_input").click().clear().type(subject);
  }

  function addEmailBody(emailBody) {
    cy.get("#mail_composer_body").click().type(emailBody);
  }

  function verifyEmailIsSent() {
    cy.intercept("POST", "https://mail.centrum.sk/?m=newmsg&op=send&w=new", {
      statusCode: 200,
    });

    // check if email was successfully sent message appears
    cy.get("#systm_ram .system-message em").should(
      "have.css",
      "background-color",
      "rgb(232, 244, 217)"
    );
    cy.get("#systm_ram .system-message span").should(
      "contain",
      "Správa bola úspešne odoslaná."
    );
  }

  function sendEmail() {
    cy.get("#qa_email_send_bottom").should("contain", "Odoslať").click();
  }

  it("Smoke test: login with correct credentials", () => {
    // insert correct username and correct password:
    fillLoginFields(Cypress.env("username"), Cypress.env("password"));
    // click on login button
    login();

    // check if "Ste prihlásený:" message appears:
    cy.get(".MailBox_text__gZ_nn").should("contain", "Ste prihlásený:");

    // check that user is logged in:
    verifyIfUserIsLoggedIn();

    // click on logout button :
    logout(logoutMailPage);

    // check if user is redirected to home page
    checkUrl(Cypress.env("mainUrl"));
  });

  it("Send mail with attachment to specific email address from adress list", () => {
    // insert correct username and correct password:
    fillLoginFields(Cypress.env("username"), Cypress.env("password"));
    // click on login button
    login();

    // check that user is logged in:
    verifyIfUserIsLoggedIn();

    // create new draft mail:
    writeNewMail();

    // select from contacts:
    selectFromContacts(Cypress.env("savedContact"));

    // fill email headline with text
    addSubject(emailSubject);

    // fill email body:
    addEmailBody(emailBody);

    // imput text file - right from fixtures folder
    // this is possible because of external library (cypress-file-upload)
    cy.get("input[type=file").attachFile("text.txt");

    // check if selected text file was added to attachments
    cy.get(".composer-attachment-content").should("contain", "text.txt");

    // click on "Send" button
    sendEmail();

    // check email is sent:
    verifyEmailIsSent();

    // click on logout button :
    logout(logoutMailPage);

    // check if user is redirected to home page
    checkUrl(Cypress.env("mainUrl"));
  });

  it("Login with incorrect username", () => {
    // log in with incorrect username
    fillLoginFields(Cypress.env("incorrectUsername"), Cypress.env("password"));

    // click on login button
    login();

    // check if error message is displayed in red div:
    checkErrorMessage("Nesprávne meno alebo heslo");
  });

  it("Login with incorrect password", () => {
    // log in with incorrect password
    fillLoginFields(Cypress.env("username"), Cypress.env("incorrectPassword"));

    // click on login button
    login();

    // check if error message is displayed in red div:
    checkErrorMessage("Nesprávne meno alebo heslo");
  });

  it("Login with incorrect both username & password", () => {
    // log in with incorrect both username & password
    fillLoginFields(
      Cypress.env("incorrectUsername"),
      Cypress.env("incorrectPassword")
    );

    // click on login button
    login();

    // check if error message is displayed in red div:
    checkErrorMessage("Nesprávne meno alebo heslo");
  });
});
